Last change 10-November-2008 
Added InstallationNotes.txt

Joachim Pimiskern